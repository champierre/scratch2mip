var MiPFinder = require("./lib/mip/finder");
var MiPRobot = require("./lib/mip/robot");

module.exports.Finder = MiPFinder;
module.exports.Robot = MiPRobot;